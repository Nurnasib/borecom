@extends('admin.master.app')

@section('content')
    <div class="content-wrapper">
        <div class="card">
            <div class="card-header">
                <h3>{{ __('All Product List') }}</h3>
            </div>
            <div class="card-body">
                @if(Session::get('message'))
                    <div class="alert alert-success alert-dismissible col-md-5">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <h5><i class="icon fas fa-check"></i> {{ Session::get('message') }}</h5>
                    </div>
                @endif

                <!-- Add new product button -->
                <a class="float-right btn bg-gradient-teal btn-sm mb-3" href="{{ route('product.create') }}">
                    <i class="fa fa-plus text-light"></i>
                </a>

                <!-- Table -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead class="bg-gradient-teal text-white">
                        <tr>
                            <th>#</th>
                            <th>Product Name</th>
                            <th>Category Name</th>
                            <th>Sub Category</th>

                            <th>Price</th>
                            <th>Deliver Charge</th>
                            <th>Image</th>
                            <th>Additional Images</th>
                            <th>Required Advanced</th>
                            <th>color-size</th>
                            <th>Status</th>
                            <th class="text-center">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($products as $val)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $val->product_name }}</td>
                                <td>{{ $val->category_name }}</td>
                                <td>{{ $val->subCategory ? $val->subCategory->sub_category_name : 'N/A' }}</td>
                                <td>{{ $val->price }}</td>
                                <td>
                                    Dhaka -{{ $val->delivery_charge_in }}<br>
                                    Country -{{ $val->delivery_charge_out }}
                                </td>
                                <td>
                                    @if(isset($val->image))
                                    <img src="{{ asset('storage/' . $val->image) }}" alt="Main Image" width="40">
                                    @endif
                                </td>
                                <td>
                                    @if(isset($val->additional_images))
                                        @foreach (json_decode($val->additional_images) as $additional)
                                            <img src="{{ asset('storage/' . $additional) }}" alt="Additional Image" width="30">
                                        @endforeach
                                    @endif
                                </td>
                                <td>{{ $val->required_advance }}</td>
                                <td>{{ $val->color }}-{{ $val->size }}</td>
                                <td>{{ $val->status }}</td>
                                <td class="text-center">
                                    <!-- Edit and Delete buttons -->
                                    <a href="{{ route('product.edit', ['product' => $val->id]) }}" class="btn btn-info btn-sm">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <form action="{{ route('product.destroy', $val->id) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this product?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
